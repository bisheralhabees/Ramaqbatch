# Study schedule 

A Pen created on CodePen.

Original URL: [https://codepen.io/Bisher-Alhabees/pen/MYbwqeY](https://codepen.io/Bisher-Alhabees/pen/MYbwqeY).

